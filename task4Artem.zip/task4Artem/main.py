alf = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя"
def read(name):
    with open(name, "r") as f:
        return f.readline()
def write(name,result):
    with open(name, "w") as f:
        return f.write(''.join(result))
def check_up(slovo1):
    slovo = str(slovo1)
    if slovo[0].isupper() and slovo[0].lower() in alf:
        for i in range(1,len(slovo)):
            if slovo[i].isupper() or slovo[i].lower() not in alf:
                return False
        return True
    else:
        return False
def check_shablon(text):
    sp = text.split(".")
    if len(sp) == 3 and sp[0].isupper() and sp[0].lower() in alf and sp[1].isupper() and sp[1].lower() in alf and sp[2] == '':
        return True
    return False
def find_name(text):
    result = []
    text_list = text.split(" ")
    for i in range(len(text_list) - 2):
        slovo = str(text_list[i])
        if check_up(slovo) and check_up(str(text_list[i + 1])) and check_up(str(text_list[i + 2])):
            result.append(slovo + " " + str(text_list[i + 1]) + " " + str(text_list[i + 2]))
        elif check_up(slovo) and check_shablon(str(text_list[i + 1])):
            result.append(slovo + " " + str(text_list[i + 1]))
    if check_up(str(text_list[-2])) and check_shablon(str(text_list[-1])):
        result.append(str(text_list[-2]) + " " + str(text_list[-1]))
    return result
result = find_name(read("input"))
write("output", result)